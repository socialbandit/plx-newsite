<?php
// alexjet_CONFIGURE.php | will self-destruct | alexjet library configuration maker | VERSION 3.6
// Copyright 2006-2010 Alexander Media, Inc. - All rights reserved.
// By: 08.14.2006_rg, 01.30.2007_rg, 04.06.2007_rg, 01.25.2008_rg, 03.24.2008_rg, 07.25.2008_rg, 09.29.2008_rg, 10.01.2008_rg,
//     12.27.2008_rg, 01.19.2009_rg, 04.21.2009_rg, 07.14.2009_rg, 09.25.2009_rg, 10.23.2009_rg, 11.29.2009_rg, 02.23.2010_rg,
//     07.23.2010_rg, 09.03.2010_rg

	// Parameters
	$mysql_hostname = 'shagbark.safesecureweb.com';
	$mysql_username = 'c57259_h217651'; 
	$mysql_password = 'paxb2011:)';
	$mysql_databasename = 'c57259_h217651';
	$glbl_dbtableprefix = 'bbp_';
	$glbl_websiteaddress = 'http://www.bigbannersplus.com/'; // {http://www.mydomain.com/} ends in {/}
	$glbl_websiteaddress_ssl = ''; // if needed, {https://www.mydomain.com/} ends in {/}, blank if not needed
	$glbl_physicalwebrootlocation = '/vservers/c57259-h217651/htdocs/'; // ends in {/}
	$glbl_maxnumberofimages = 100;
	$glbl_companyname = 'Big Banners Plus';
	$glbl_createdyear = '2007';
	$glbl_backgroundcolor_default = '#000000';
	$glbl_notes_default = '&nbsp;';
	$glbl_uploadsrootfolder = 'uploads/'; // uploads/ -- ends in {/}
	$glbl_thumbnailimages_prefix = 'thumb_'; // thumb_
	$glbl_templatesfolder = 'htmltemplates/'; // htmltemplates/ -- ends in blank if on the root otherwise ends in {/}
	$glbl_templatedefaultfilename = 'default.php'; // typically default.php
	$glbl_superusername = 'alexbig';
	$glbl_supercode = 'alexbig1';
	$glbl_adminusername = 'kgore';
	$glbl_admincode = 'kg1270';
	$glbl_sendformsfromemailaddress = 'root@bigbannerplus.com';
	$glbl_sendformstoemailaddress = 'orders@bigbannersplus.com';
	$glbl_allowpagemanagement = true; // true | false
	$glbl_allowsectionmanagement = true; // true | false
	$glbl_loginpagepath = ''; // just page keyword | for instance: articles or articles/ or articles/index.php | do not start with / | blank if none
	$glbl_customphpscriptpath = 'php/bigbannersplus.php'; // if needed, used in connection with dynamic pages | for instance: php/mydomain.php

	// Safety
	echo('locked. nothing done.');
	exit(0);
		
	// Create configuration disk file (config.php)
	if ($glbl_allowpagemanagement)
		$glbl_allowpagemanagement_strng = 'true';
	else
		$glbl_allowpagemanagement_strng = 'false';
	if ($glbl_allowsectionmanagement)
		$glbl_allowsectionmanagement_strng = 'true';
	else
		$glbl_allowsectionmanagement_strng = 'false';	
	$configFileName = 'config.php';
	if (file_exists($configFileName))
		unlink($configFileName);
	$configFileHandle = fopen($configFileName, 'w') or die('can\'t open file');
	$fileContent = '<?php $mysql_hostname=\'' . $mysql_hostname . '\';' .
			 	   '$mysql_username=\'' . $mysql_username . '\';' .
				   '$mysql_password=\'' . $mysql_password . '\';' .
				   '$mysql_databasename=\'' . $mysql_databasename . '\';' .
				   '$glbl_dbtableprefix=\'' . $glbl_dbtableprefix . '\';' .
				   '$glbl_allowpagemanagement=' . $glbl_allowpagemanagement_strng . ';' .
				   '$glbl_allowsectionmanagement=' . $glbl_allowsectionmanagement_strng . ';' .
				   '$glbl_sendformsfromemailaddress=\'' . $glbl_sendformsfromemailaddress . '\';' .
				   '$glbl_sendformstoemailaddress=\'' . $glbl_sendformstoemailaddress . '\';' .
				   '$glbl_maxnumberofimages=' . $glbl_maxnumberofimages . ';' .
				   '$glbl_companyname=\'' . $glbl_companyname . '\';' .
   				   '$glbl_createdyear=\'' . $glbl_createdyear . '\';' .		
   				   '$glbl_backgroundcolor_default=\'' . $glbl_backgroundcolor_default . '\';' .
   				   '$glbl_notes_default=\'' . $glbl_notes_default . '\';' .
   				   '$glbl_thumbnailimages_prefix=\'' . $glbl_thumbnailimages_prefix . '\';' .
   				   '$glbl_uploadsrootfolder=\'' . $glbl_uploadsrootfolder . '\';' .
				   '$glbl_physicalwebrootlocation=\'' . $glbl_physicalwebrootlocation . '\';' .
   				   '$glbl_websiteaddress=\'' . $glbl_websiteaddress . '\';' .
   				   '$glbl_websiteaddress_ssl=\'' . $glbl_websiteaddress_ssl . '\';' .
   				   '$glbl_templatesfolder=\'' . $glbl_templatesfolder . '\';' .
   				   '$glbl_loginpagepath=\'' . $glbl_loginpagepath . '\';' .
				   '$glbl_customphpscriptpath=\'' . $glbl_customphpscriptpath . '\'; ?>';
	fwrite($configFileHandle, $fileContent);
	fclose($configFileHandle);
	
	// Function library
	$_GET['event'] = 'void';
	include('alexjet.php');
	
    // Connect to MySQL
	$link = mysql_connect($mysql_hostname, $mysql_username, $mysql_password);
	if (!$link)
	  die(mysql_error());
    // Select database on MySQL server 
	$db_selected = mysql_select_db($mysql_databasename, $link);
	if (!$db_selected)
	   die(mysql_error());
	// ** Make query to check if 'imageinformation' table already exists and drop it
	$query = sprintf('DROP TABLE IF EXISTS ' . $glbl_dbtableprefix . 'imageinformation');	
	// Perform Query
	$result = mysql_query($query);
	// Check result | This shows the actual query sent to MySQL, and the error. Useful for debugging.
	if (!$result) {
   		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		die($message);
	}
	// Make query to create imageinformation table
	$query = sprintf('CREATE TABLE ' . $glbl_dbtableprefix . 'imageinformation( 
         		ID                VARCHAR(250) NOT NULL PRIMARY KEY,
         		BackgroundColor   VARCHAR(50)  NULL,
				Notes             VARCHAR(250) NULL,
				Keywords          VARCHAR(250) NULL,
         		Updated           TIMESTAMP(8) NOT NULL)');
	// Perform Query
	$result = mysql_query($query);
	// Check result | This shows the actual query sent to MySQL, and the error. Useful for debugging.
	if (!$result) {
   		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		die($message);
	}
	// ** Make query to check if 'users' table already exists and drop it
	$query = sprintf('DROP TABLE IF EXISTS ' . $glbl_dbtableprefix . 'users');
	// Perform Query
	$result = mysql_query($query);
	// Check result | This shows the actual query sent to MySQL, and the error. Useful for debugging.
	if (!$result) {
   		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		die($message);
	}
	// Make query to create users table
	$query = sprintf('CREATE TABLE ' . $glbl_dbtableprefix . 'users( 
         		UserName          VARCHAR(15)  NOT NULL PRIMARY KEY,
        		Code              VARCHAR(15)  NOT NULL,
				UserType          VARCHAR(50)  NOT NULL,
				UID				  VARCHAR(25)  NOT NULL,		
        		Updated           TIMESTAMP(8) NOT NULL)');
	// Perform Query
	$result = mysql_query($query);
	// Check result | This shows the actual query sent to MySQL, and the error. Useful for debugging.
	if (!$result) {
   		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		die($message);
	}
	// Make query to insert superuser info.
	$query = sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'users (UserName, Code, UserType, UID) 
        		      VALUES (\'%s\', \'%s\', \'%s\', \'%s\')', $glbl_superusername, $glbl_supercode, 'superuser', makeUC());
	// Perform Query
	$result = mysql_query($query);
	// Make query to insert adminuser info.
	$query = sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'users (UserName, Code, UserType, UID) 
        		      VALUES (\'%s\', \'%s\', \'%s\', \'%s\')', $glbl_adminusername, $glbl_admincode, 'adminuser', makeUC());
	// Perform Query
	$result = mysql_query($query);
	// ** Make query to check if 'usersallowedpages' table already exists and drop it
	$query = sprintf('DROP TABLE IF EXISTS ' . $glbl_dbtableprefix . 'usersallowedpages');
	// Perform Query
	$result = mysql_query($query);
	// Check result | This shows the actual query sent to MySQL, and the error. Useful for debugging.
	if (!$result) {
   		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		die($message);
	}
	// Make query to create usersallowedpages table
	$query = sprintf('CREATE TABLE ' . $glbl_dbtableprefix . 'usersallowedpages(
				UserUID		      VARCHAR(25) NOT NULL,	
				PageRegistryUID   VARCHAR(25) NOT NULL,	
				PRIMARY KEY       (UserUID, PageRegistryUID))');						
	// Perform Query
	$result = mysql_query($query);
	// Check result | This shows the actual query sent to MySQL, and the error. Useful for debugging.
	if (!$result) {
   		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		die($message);
	}
	// ** Make query to check if 'editablecontent' table already exists and drop it
	$query = sprintf('DROP TABLE IF EXISTS ' . $glbl_dbtableprefix . 'editablecontent');	
	// Perform Query
	$result = mysql_query($query);
	// Check result | This shows the actual query sent to MySQL, and the error. Useful for debugging.
	if (!$result) {
   		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		die($message);
	}
	// Make query to create editablecontent table
	$query = sprintf('CREATE TABLE ' . $glbl_dbtableprefix . 'editablecontent( 
			    ContentID VARCHAR(250) NOT NULL PRIMARY KEY,
			    Content   TEXT         NULL,
			    Updated   TIMESTAMP(8) NOT NULL)');
	// Perform Query
	$result = mysql_query($query);
	// Check result | This shows the actual query sent to MySQL, and the error. Useful for debugging.
	if (!$result) {
   		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		die($message);
	}
	// ** Make query to check if 'selectableimages' table already exists and drop it
	$query = sprintf('DROP TABLE IF EXISTS ' . $glbl_dbtableprefix . 'selectableimages');	
	// Perform Query
	$result = mysql_query($query);
	// Check result | This shows the actual query sent to MySQL, and the error. Useful for debugging.
	if (!$result) {
   		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		die($message);
	}
	// Make query to create selectableimages table
	$query = sprintf('CREATE TABLE ' . $glbl_dbtableprefix . 'selectableimages( 
			    ImageID    VARCHAR(250) NOT NULL PRIMARY KEY,
			    FolderName VARCHAR(250) NOT NULL,
				ImagePath  VARCHAR(250) NULL,
			    Updated    TIMESTAMP(8) NOT NULL)');
	// Perform Query
	$result = mysql_query($query);
	// Check result | This shows the actual query sent to MySQL, and the error. Useful for debugging.
	if (!$result) {
   		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		die($message);
	}
	// ** Make query to check if 'storedqueries' table already exists and drop it
	$query = sprintf('DROP TABLE IF EXISTS ' . $glbl_dbtableprefix . 'storedqueries');	
	// Perform Query
	$result = mysql_query($query);
	// Check result | This shows the actual query sent to MySQL, and the error. Useful for debugging.
	if (!$result) {
   		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		die($message);
	}
	// Make query to create storedqueries table
	$query = sprintf('CREATE TABLE ' . $glbl_dbtableprefix . 'storedqueries( 
			    QueryKey               VARCHAR(250) NOT NULL PRIMARY KEY,
			    QueryStatement         TEXT         NOT NULL,
				InputFields            VARCHAR(250) NULL,
				AuthenticationRequired BOOL         NOT NULL,
			    Updated                TIMESTAMP(8) NOT NULL)');
	// Perform Query
	$result = mysql_query($query);
	// Check result | This shows the actual query sent to MySQL, and the error. Useful for debugging.
	if (!$result) {
   		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		die($message);
	}
	// Make query to insert a default stored query. - states -
	$query = sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'storedqueries (QueryKey, QueryStatement, InputFields, AuthenticationRequired) 
        		      VALUES (\'%s\', \'%s\', \'%s\', %s)', 'states', 'SELECT * FROM ' . $glbl_dbtableprefix . 'states ORDER BY State', '', 0);
	// Perform Query
	$result = mysql_query($query);
	// Make query to insert a default stored query. - pageregistry -
	$query = sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'storedqueries (QueryKey, QueryStatement, InputFields, AuthenticationRequired) 
        		      VALUES (\'%s\', \'%s\', \'%s\', %s)', 'pageregistry',
					                                        addslashes(('SELECT    r.PageID, r.SectionID, r.TemplatePath, r.PagePath, t.Description AS TemplateDescription, ' .
																		'          r.PageStatus, r.MembersOnly, r.SortOrder, e.Content AS PageTitle, r.PageLevel, r.UID ' .
																		'FROM      ' . $glbl_dbtableprefix . 'pageregistry r ' . 
																		'LEFT JOIN ' . $glbl_dbtableprefix . 'editablecontent e ON e.ContentID = r.PageTitleContentID ' .
																		'LEFT JOIN ' . $glbl_dbtableprefix . 'pagetemplates t ON t.TemplatePath = r.TemplatePath ' .
																		'WHERE     r.SectionID = \'' . '{$sectionid$}' . '\' AND LockPage = 0 ' .
																		'ORDER BY  r.SortOrder')
																	  ),
															'sectionid', 1);
	// Perform Query
	$result = mysql_query($query);
	// Make query to insert a default stored query. - editablearea -
	$query = sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'storedqueries (QueryKey, QueryStatement, InputFields, AuthenticationRequired) 
        		      VALUES (\'%s\', \'%s\', \'%s\', %s)', 'editablearea',
					                                        addslashes(('SELECT * FROM ' . $glbl_dbtableprefix . 'editablecontent WHERE ContentID LIKE \'' . '{$contentid$}' . '\' ORDER BY ContentID')
																	  ),
															'contentid', 1);
	// Perform Query
	$result = mysql_query($query);
	// Make query to insert a default stored query. - pageregistry4sectionsmgt -
	$query = sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'storedqueries (QueryKey, QueryStatement, InputFields, AuthenticationRequired) 
        		      VALUES (\'%s\', \'%s\', \'%s\', %s)', 'pageregistry4sectionsmgt',
					                                        addslashes(('SELECT    CONCAT(IF(r.SectionID = \'root/\', \'\', r.SectionID), r.PageID, \'/\') AS SectionID, ' .
																		'		   e.Content AS Description ' .
																		'FROM      ' . $glbl_dbtableprefix . 'pageregistry r ' .
																		'LEFT JOIN ' . $glbl_dbtableprefix . 'editablecontent e ON e.ContentID = r.PageTitleContentID ' .
																		'WHERE     r.LockPage = 0 AND r.PageLevel <= 3 AND ' .
																		'          (SELECT COUNT(*) FROM ' . $glbl_dbtableprefix . 'pagesections WHERE SectionID = CONCAT(IF(r.SectionID = \'root/\', \'\', r.SectionID), r.PageID, \'/\')) < 1 ' .
																		'ORDER BY  CONCAT(IF(r.SectionID != \'root/\', \'root/\', \'\'), r.SectionID, r.PageID, \'/\'), r.SortOrder')
																	  ),
															'', 1);
	// Perform Query
	$result = mysql_query($query);
	// Make query to insert a default stored query. - userlist4usersmgt -
	$query = sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'storedqueries (QueryKey, QueryStatement, InputFields, AuthenticationRequired) 
        		      VALUES (\'%s\', \'%s\', \'%s\', %s)', 'userlist4usersmgt',
					                                        addslashes(('SELECT    u.UserName, u.Code, u.UserType, u.UID, ' .
					                                        		    '          (SELECT GROUP_CONCAT(CONCAT(PageRegistryUID, \'|\', ' .
					                                        		    '                                      (SELECT CONCAT(SectionID, PageID) ' .
					                                        		    '                                       FROM   ' . $glbl_dbtableprefix . 'pageregistry ' .
					                                        		    '                                       WHERE  UID = ' . $glbl_dbtableprefix . 'usersallowedpages.PageRegistryUID LIMIT 1) ' .
					                                        		    '                                     ) SEPARATOR \'~\') ' .
					                                        		    '           FROM   ' . $glbl_dbtableprefix . 'usersallowedpages ' .
					                                        		    '           WHERE  UserUID = u.UID) AS AllowedPages ' .
																		'FROM      users u ' .
																		'WHERE     u.UserType != \'superuser\' ' .
																		'ORDER BY  u.UserName')
																	  ),
															'', 1);
	
	
		
	
	
	// Perform Query
	$result = mysql_query($query);
	// ** Make query to check if 'states' table already exists and drop it
	$query = sprintf('DROP TABLE IF EXISTS ' . $glbl_dbtableprefix . 'states');	
	// Perform Query
	$result = mysql_query($query);
	// Check result | This shows the actual query sent to MySQL, and the error. Useful for debugging.
	if (!$result) {
   		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		die($message);
	}
	// Make query to create states table
	$query = sprintf('CREATE TABLE ' . $glbl_dbtableprefix . 'states( 
			    State       VARCHAR(10) NOT NULL PRIMARY KEY,
			    Description VARCHAR(50) NOT NULL)');
	// Perform Query
	$result = mysql_query($query);
	// Check result | This shows the actual query sent to MySQL, and the error. Useful for debugging.
	if (!$result) {
   		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		die($message);
	}
	// Make queries to insert states.
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'AL', 'Alabama'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'AK', 'Alaska'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'AZ', 'Arizona'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'AR', 'Arkansas'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'CA', 'California'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'CO', 'Colorado'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'CT', 'Connecticut'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'DE', 'Delaware'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'DC', 'Dist. of Columbia'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'FL', 'Florida'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'GA', 'Georgia'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'HI', 'Hawaii'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'ID', 'Idaho'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'IL', 'Illinois'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'IN', 'Indiana'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'IA', 'Iowa'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'KS', 'Kansas'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'KY', 'Kentucky'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'LA', 'Louisiana'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'ME', 'Maine'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'MD', 'Maryland'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'MA', 'Massachusetts'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'MI', 'Michigan'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'MN', 'Minnesota'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'MS', 'Mississippi'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'MO', 'Missouri'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'MT', 'Montana'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'NE', 'Nebraska'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'NV', 'Nevada'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'NH', 'New Hampshire'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'NJ', 'New Jersey'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'NM', 'New Mexico'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'NY', 'New York'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'NC', 'North Carolina'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'ND', 'North Dakota'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'OH', 'Ohio'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'OK', 'Oklahoma'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'OR', 'Oregon'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'PA', 'Pennsylvania'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'RI', 'Rhode Island'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'SC', 'South Carolina'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'SD', 'South Dakota'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'TN', 'Tennessee'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'TX', 'Texas'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'UT', 'Utah'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'VT', 'Vermont'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'VA', 'Virginia'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'WA', 'Washington'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'WV', 'West Virginia'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'WI', 'Wisconsin'));
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'states (State, Description) VALUES (\'%s\', \'%s\')', 'WY', 'Wyoming'));	
	// ** Make query to check if 'pagetemplates' table already exists and drop it
	$query = sprintf('DROP TABLE IF EXISTS ' . $glbl_dbtableprefix . 'pagetemplates');	
	// Perform Query
	$result = mysql_query($query);
	// Check result | This shows the actual query sent to MySQL, and the error. Useful for debugging.
	if (!$result) {
   		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		die($message);
	}
	// Make query to create pagetemplates table
	$query = sprintf('CREATE TABLE ' . $glbl_dbtableprefix . 'pagetemplates( 
			    TemplatePath         VARCHAR(250) NOT NULL PRIMARY KEY,
			    Description          VARCHAR(250) NOT NULL,
				SortOrder            INT          NULL,
				ShowInPageManager    INT          NOT NULL,
			    Updated              TIMESTAMP(8) NOT NULL)');
	// Perform Query
	$result = mysql_query($query);
	// Check result | This shows the actual query sent to MySQL, and the error. Useful for debugging.
	if (!$result) {
   		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		die($message);
	}
	// Make query to insert default page template.
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'pagetemplates (TemplatePath, Description, SortOrder, ShowInPageManager) VALUES (\'%s\', \'%s\', %s, %s)', ($glbl_templatesfolder . $glbl_templatedefaultfilename), 'Default', 0, 1));
	// ** Make query to check if 'pagesections' table already exists and drop it
	$query = sprintf('DROP TABLE IF EXISTS ' . $glbl_dbtableprefix . 'pagesections');	
	// Perform Query
	$result = mysql_query($query);
	// Check result | This shows the actual query sent to MySQL, and the error. Useful for debugging.
	if (!$result) {
   		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		die($message);
	}
	// Make query to create pagesections table
	$query = sprintf('CREATE TABLE ' . $glbl_dbtableprefix . 'pagesections( 
			    SectionID            VARCHAR(250) NOT NULL PRIMARY KEY,
				Description       	 VARCHAR(250) NOT NULL,
				DefaultTemplatePath  VARCHAR(250) NULL,
				SortOrder            INT          NULL,
				ShowInPageManager    INT          NOT NULL,
			    Updated              TIMESTAMP(8) NOT NULL)');
	// Perform Query
	$result = mysql_query($query);
	// Check result | This shows the actual query sent to MySQL, and the error. Useful for debugging.
	if (!$result) {
   		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		die($message);
	}
	// Make query to insert root pagesection.
	$result = mysql_query(sprintf('INSERT INTO ' . $glbl_dbtableprefix . 'pagesections (SectionID, Description, SortOrder, ShowInPageManager) VALUES (\'%s\', \'%s\', %s, %s)', 'root/', 'Root', 0, 1));
	// ** Make query to check if 'pageregistry' table already exists and drop it
	$query = sprintf('DROP TABLE IF EXISTS ' . $glbl_dbtableprefix . 'pageregistry');	
	// Perform Query
	$result = mysql_query($query);
	// Check result | This shows the actual query sent to MySQL, and the error. Useful for debugging.
	if (!$result) {
   		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		die($message);
	}
	// Make query to create pageregistry table
	$query = sprintf('CREATE TABLE ' . $glbl_dbtableprefix . 'pageregistry(
			    PageID             VARCHAR(80)  NOT NULL,
				SectionID          VARCHAR(250) NOT NULL,
				TemplatePath       VARCHAR(250) NOT NULL,
				PagePath	       VARCHAR(250) NOT NULL,
				PageLevel	       VARCHAR(50)  NULL,
				PageStatus         VARCHAR(50)  NOT NULL,
				SortOrder          INT          NULL,
				PageTitleContentID VARCHAR(250) NULL,
				LockPage           INT 			NULL,
				MembersOnly        INT 			NULL,
				UID				   VARCHAR(25)  NOT NULL,	
			    Updated            TIMESTAMP(8) NOT NULL,
				PRIMARY KEY        (PageID, SectionID))');
	// Perform Query
	$result = mysql_query($query);
	// Check result | This shows the actual query sent to MySQL, and the error. Useful for debugging.
	if (!$result) {
   		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		die($message);
	}
	// ** Make query to check if 'tokens' table already exists and drop it
	$query = sprintf('DROP TABLE IF EXISTS ' . $glbl_dbtableprefix . 'tokens');	
	// Perform Query
	$result = mysql_query($query);
	// Check result | This shows the actual query sent to MySQL, and the error. Useful for debugging.
	if (!$result) {
   		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		die($message);
	}
	// Make query to create tokens table
	$query = sprintf('CREATE TABLE ' . $glbl_dbtableprefix . 'tokens( 
			    TokenID       VARCHAR(250) NOT NULL PRIMARY KEY,
			    Expiration    INT          NOT NULL,
			    Updated       TIMESTAMP(8) NOT NULL)');
	// Perform Query
	$result = mysql_query($query);
	// Check result | This shows the actual query sent to MySQL, and the error. Useful for debugging.
	if (!$result) {
   		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		die($message);
	}
	// Close connection
	mysql_close($link);
	// Self destroy
	unlink('alexjet_CONFIGURE.php');
	// End
	echo('configuration done.');
?>